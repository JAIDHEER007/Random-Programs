SR_LIMIT = 101
MAX_LOOP_ITER = 10

class urls:
    SIEBEL_HOME_URL = 'https://crm.es.oneadp.com/siebel/app/callcenter/enu?SWECmd=Start&'
    SR_URL = 'https://crm.es.oneadp.com/siebel/app/callcenter/enu?SWECmd=GotoView&SWEView=Service+Request+Screen+Homepage+View'
    SIEBEL_LOGOUT_URL = 'https://crm.es.oneadp.com/siebel/app/callcenter/enu?SWECmd=Logoff&SWEPreLd=1&SWETS={epoch_time}'


class ids:
    LOGIN_UID_TEXT_BOX = 's_swepi_1'
    LOGIN_PWD_TEXT_BOX = 's_swepi_2'
    LOGIN_BUTTON = 's_swepi_22'
    LOGIN_STATUS_BAR_ID = 'statusBar'
    SERVICE_REQUESTS_ANCHOR = 'ui-id-99'
    SERVICE_REQUESTS_GO_BUTTON = 's_4_1_18_0_Ctrl'
    SR_NUMBER = 's_1_1_174_0_mb'
    PREVIOUS_SR_ARROW = 's_1_1_238_0'
    NEXT_SR_ARROW = 's_1_1_236_0'
    SR_COUNT = 's_1_rc'
    SAVE_BUTTON = 's_1_1_155_0_Ctrl'
    SR_OPTIONS_NAVIGATION_BAR = 's_vctrl_div_tabScreen'
    SR_OPTIONS_NAVIGATION_DROP_DOWN = 'j_s_vctrl_div_tabScreen'
    SR_CLOSE_BUTTON = 's_1_1_207_0_Ctrl'
    SR_NOTES_ADD_BUTTON = 's_2_1_7_0_Ctrl'
    SR_NOTE_DIV = 's_2_l_scroll'

class names:
    SR_NUMBER_BOX = 's_4_1_19_0'
    SR_SUPER_TYPE_BOX = 's_1_1_54_0'
    SR_TYPE_BOX = 's_1_1_194_0'
    SR_SUB_TYPE_BOX = 's_1_1_195_0'
    SR_SOURCE_BOX = 's_1_1_197_0'
    SR_ASSET_BOX = 's_1_1_191_0'
    SR_ACCOUNT_NAME_BOX = 's_1_1_101_0'
    SR_STATUS_BOX = 's_1_1_200_0'
    SR_ABSTRACT_BOX = 's_1_1_188_0'

class xpaths:
    SR_NAV_BAR_ITEMS = "//ul/li/a[text()='{item_name}']"
    SR_NAV_BAR_DROPDOWN_OPTION = "//ul/li/select/option[text()='{item_name}']"
    SR_NOTE_DESCRIPTION = "//table/tbody/tr[@id=1]/td[@aria-roledescription='Description']"
    SR_NOTE_TEXTAREA = "//table/tbody/tr[@id=1]/td[@aria-roledescription='Description']/textarea"
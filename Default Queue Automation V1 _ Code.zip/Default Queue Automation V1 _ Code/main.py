from selenium import webdriver 
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options 

from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import JavascriptException

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait as wdw
from selenium.webdriver.support import expected_conditions as EC

import time

import gui

from constants import *
from automator import *

from csv_handler import handler
from base_logger import logger

#Disabling console logging
opt = Options() 
opt.add_experimental_option("excludeSwitches", ["enable-logging"]) 

#Stopping images from Loading 
prefs = {"profile.managed_default_content_settings.images": 2}
opt.add_experimental_option("prefs", prefs)

#Avoiding "Your Connection is not private" error
opt.add_argument('--ignore-ssl-errors=yes')
opt.add_argument('--ignore-certificate-errors')

#Performance boost
opt.add_argument('--no-proxy-server') 
opt.add_argument("--proxy-server='direct://'")
opt.add_argument("--proxy-bypass-list=*")

# Keep the browser open
opt.add_experimental_option("detach", True)

# Open the Browser in maximized mode
opt.add_argument("--start-maximized")

# Make the Process headless, Chrome Window will not open
# opt.add_argument('--headless')

try:
    # select chromedriver path
    chromedriver_executable_path = gui.show_file_selector(title = "Chromedriver", allowed_file_type = ".exe")
    service = Service(executable_path = chromedriver_executable_path)
    driver = webdriver.Chrome(options = opt, service = service) 

    logger.info("Chrome Driver Initialized")

    driver.get(urls.SIEBEL_HOME_URL)


    retry = False
    while True:
        credentials = gui.show_login_box(retry = retry)
        if credentials is None: 
            logger.error("Login Action Aborted")
            raise Exception("Login Action Aborted")
        login_to_siebel(driver = driver, uid = credentials[0], pwd = credentials[1])
        

        try: retry = len(driver.find_element(By.ID, ids.LOGIN_STATUS_BAR_ID).text) > 0 
        except NoSuchElementException: break
            
    logger.info(f"User Logged in as {credentials[0]}")

    csv_path = gui.show_file_selector(title="CSV File", allowed_file_type=".csv")

    csv_handler = handler(csv_path = csv_path)

    total_sr_count = csv_handler.total_srs()
    logger.info(f"Total SR Count: {total_sr_count}")

    for i in range(0, total_sr_count, SR_LIMIT):
        search_for_sr(driver = driver, sr_string = csv_handler.get_sr_string(start = i, end = (i + SR_LIMIT)))
        while True:
            start_time = time.perf_counter()

            sr_number = get_sr_number(driver)
            logger.info(f"Processing {sr_number}")

            sr_status_siebel = get_sr_status(driver = driver)
            logger.debug(f"Status: {sr_status_siebel}")

            if sr_status_siebel != "Closed":

                open_siebel_navbar_item(driver = driver, item_name = "Notes")
                add_sr_note(driver = driver, sr_note = 'Closing due to inactivity and no follow up from the requester.')

                # Validate and Update the SR Field
                validate_and_update_abstract(driver = driver, abstract = 'This is a redundant SR')
                
                
                # SR Account Name Field
                siebel_form_send_keys(driver = driver, wait_time = 10, 
                                    by_field = By.NAME, query_field = names.SR_ACCOUNT_NAME_BOX, 
                                    key = "ADP CORPORATE (ALL BU'S)")

                # SR Super Type Field
                siebel_form_send_keys(driver = driver, wait_time = 10, 
                                    by_field = By.NAME, query_field = names.SR_SUPER_TYPE_BOX, 
                                    key = "General")

                # SR Type Field
                siebel_form_send_keys(driver = driver, wait_time = 10, 
                                    by_field = By.NAME, query_field = names.SR_TYPE_BOX, 
                                    key = 'Internal Support')

                # SR Sub Type Field
                siebel_form_send_keys(driver = driver, wait_time = 10, 
                                    by_field = By.NAME, query_field = names.SR_SUB_TYPE_BOX, 
                                    key = 'Question / Inquiry')

                # SR Source Field
                siebel_form_send_keys(driver = driver, wait_time = 10, 
                                    by_field = By.NAME, query_field = names.SR_SOURCE_BOX, 
                                    key = 'Automated Email')

                # SR Asset Field
                siebel_form_send_keys(driver = driver, wait_time = 10, 
                                    by_field = By.NAME, query_field = names.SR_ASSET_BOX, 
                                    key = 'Siebel CRM Call Center')

                
                time.sleep(5)
                

                save_sr(driver = driver)
                close_sr(driver = driver)
        
            end_time = time.perf_counter()
            
            if csv_handler.get_status(sr_number = sr_number) != "Done":
                logger.info("SR status is not done in csv")
                csv_handler.set_time_taken(sr_number = sr_number, time_taken = str(round(end_time - start_time, 2)))
                csv_handler.set_status(sr_number = sr_number, status = "Done")
            logger.info("SR Processing Done")

            # Moving code
            sr_index = get_sr_index(driver = driver)
            logger.info(f"SR Index: {sr_index}")
            if ((sr_index % SR_LIMIT) == 0) or (sr_index == total_sr_count): 
                logger.debug(f"Break Statement executed at SR Index {sr_index}")
                break
            else: 
                logger.debug("Next SR")
                click_next_arrow(driver = driver)
        
except Exception as exp:
    logger.exception(exp)
finally:
    if 'csv_handler' in locals():
        csv_handler.save_csv()
    if 'driver' in locals():
        logout_from_siebel(driver = driver)
        driver.quit() #Used to close the driver
        logger.info("Closed the driver")
    else:
        logger.error("Lost the scope of WebDriver")


    
    



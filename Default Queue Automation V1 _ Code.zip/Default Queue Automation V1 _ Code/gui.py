import easygui as eg
from base_logger import logger

def show_login_box(retry = False) -> list:
    logger.debug("Login Box created")
    credentials = eg.multpasswordbox(
        "⚠️ Please enter valid Siebel credentials" if retry else "Please enter Siebel credentials",
        'Siebel Login Credentials', ["User ID", "Password"])

    if credentials and (len(credentials[0]) < 1 or len(credentials[1]) < 1): 
        logger.warning("Enter valid credentials")
        eg.msgbox("Please enter valid credentials", "ERROR", "OK")
        credentials = show_login_box()
    return credentials


def show_file_selector(title, allowed_file_type = None):
    logger.debug("File select Box created")
    file_path = eg.fileopenbox(msg = "Please select a file", title = title, filetypes = allowed_file_type)
    if file_path:
        if allowed_file_type and not file_path.endswith(allowed_file_type):
            logger.warning("Invalid file format")
            raise ValueError("Selected file format is not matching")
    else: 
        logger.warning("File Not selected")
        raise Exception("Please select a file from the selection box")

    return file_path
import logging
import logging.config
from colorama import Fore, Back, Style, just_fix_windows_console
from datetime import datetime
import sys
import os


just_fix_windows_console()

class CustomFormatter(logging.Formatter):
    levelname = "[%(levelname)s]"
    format_string = " - %(asctime)s - %(name)s - %(message)s (%(filename)s:%(lineno)d)"
    FORMATS = {
        logging.DEBUG: Back.BLUE + Fore.WHITE + levelname + Style.RESET_ALL + format_string,
        logging.INFO: Back.BLUE + Fore.WHITE + levelname + Style.RESET_ALL + format_string,
        logging.WARNING: Back.YELLOW + Fore.WHITE + levelname + Style.RESET_ALL + format_string,
        logging.ERROR: Back.RED + Fore.WHITE + levelname + Style.RESET_ALL + format_string,
        logging.CRITICAL: Back.RED + Fore.WHITE + levelname + Style.RESET_ALL + format_string,
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)
    
class FileCustomFormatter(logging.Formatter):
    format_string = "%(asctime)s - %(name)s - [%(levelname)s] - %(message)s (%(filename)s:%(lineno)d)"
    def format(self, record):
        formatter = logging.Formatter(self.format_string)
        return formatter.format(record)

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# create console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(CustomFormatter())

current_datetime = datetime.now()
datetime_string = current_datetime.strftime("%Y%m%d_%H%M%S")

if getattr(sys, 'frozen', False): # we are running in a bundle
    bundle_dir = sys._MEIPASS # This is where the files are unpacked to
else: # normal Python environment
    bundle_dir = os.path.dirname(os.path.abspath(__file__))

dir_path = os.path.join(bundle_dir, "logs")
if not os.path.exists(dir_path):
    os.makedirs(dir_path)

# Create file handler and set level to debug
fh = logging.FileHandler(os.path.join(dir_path, f'{datetime_string}.log'))
fh.setLevel(logging.DEBUG)
fh.setFormatter(FileCustomFormatter())  # Use FileCustomFormatter for file handler

# Add handlers to the logger
logger.addHandler(ch)
logger.addHandler(fh)
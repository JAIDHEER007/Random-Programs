import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import pandas as pd
from base_logger import logger

SR_COL = "SR #"
STATUS_COL = "Processing Status"
TT_COL = "Time Taken"

import functools
def log_entry(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger.debug("Entered function: {function_name}".format(function_name = func.__name__))
        return func(*args, **kwargs)
    return wrapper

class handler:
    def __init__(self, csv_path) -> None:
        logger.debug("CSV Handler Created")
        self.csv_path = csv_path
        logger.info(f"Provided CSV Path {self.csv_path}")

        self.df = pd.read_csv(self.csv_path, delimiter='\t', encoding='utf-16', index_col=False)
        
        if STATUS_COL not in self.df.columns or TT_COL not in self.df.columns: 
            logger.debug(f"{STATUS_COL}, {TT_COL} created")

            # self.df = self.df[SR_COL].to_frame()
            self.df[STATUS_COL] = ""
            self.df[TT_COL] = ""
        else:
            logger.debug(f"{STATUS_COL}, {TT_COL} already present")

            # self.df = self.df[[SR_COL, STATUS_COL, TT_COL]]
        self.df = self.df.dropna(subset=[SR_COL])
            
        self.sr_count = len(self.df)

    @log_entry
    def get_sr_string(self, start, end) -> str:
        sr_numbers = self.df[SR_COL].iloc[start:end].astype('str').tolist()
        return " OR ".join(sr_numbers).strip()

    @log_entry
    def get_status(self, sr_number: str) -> str:
        row = self.df.loc[self.df[SR_COL] == sr_number]
        if row.empty:
            raise ValueError(f"SR number '{sr_number}' not found")
        return row[STATUS_COL].values[0]
    
    @log_entry
    def set_status(self, sr_number: str, status: str) -> None:
        row_index = self.df.index[self.df[SR_COL] == sr_number].to_list()

        if row_index:
            self.df.loc[row_index[0], STATUS_COL] = status
        else: raise ValueError(f"SR Number '{sr_number}' not found")

    @log_entry
    def set_time_taken(self, sr_number: str, time_taken: str) -> None:
        row_index = self.df.index[self.df[SR_COL] == sr_number].to_list()

        if row_index:
            self.df.loc[row_index[0], TT_COL] = time_taken
        else: raise ValueError(f"SR Number '{sr_number}' not found")

    @log_entry
    def total_srs(self) -> int:
        return self.sr_count

    @log_entry
    def save_csv(self) -> None:
        try:
            self.df.to_csv(self.csv_path, sep='\t', index=False, encoding='utf-16')
            logger.info("CSV File Saved")
        except Exception as exp:
            logger.exception(exp)

        
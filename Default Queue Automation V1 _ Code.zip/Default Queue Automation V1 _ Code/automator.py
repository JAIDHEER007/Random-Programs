from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import JavascriptException
from selenium.common.exceptions import StaleElementReferenceException
from selenium.common.exceptions import InvalidElementStateException

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait as wdw
from selenium.webdriver.support import expected_conditions as EC

from base_logger import logger
import time

from constants import *

import functools

def log_entry(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger.debug("Entered function: {function_name}".format(function_name = func.__name__))
        return func(*args, **kwargs)
    return wrapper


@log_entry
def login_to_siebel(driver, uid, pwd) -> None:

    login_uid_text_box = driver.find_element(By.ID, ids.LOGIN_UID_TEXT_BOX)
    login_uid_text_box.clear()
    login_uid_text_box.send_keys(uid)

    login_pwd_text_box = driver.find_element(By.ID, ids.LOGIN_PWD_TEXT_BOX)
    login_pwd_text_box.clear()
    login_pwd_text_box.send_keys(pwd)

    driver.find_element(By.ID, ids.LOGIN_BUTTON).click()

@log_entry
def get_sr_number(driver) -> str:
    web_element = wdw(driver,10).until(
        EC.presence_of_element_located((By.ID, ids.SR_NUMBER)) 
    )
    return web_element.get_attribute('innerHTML').strip()

@log_entry
def logout_from_siebel(driver) -> None:
    driver.get(urls.SIEBEL_LOGOUT_URL.format(epoch_time = int(time.time())))
    logger.info("Logged out")

@log_entry
def siebel_form_send_keys(driver, wait_time, by_field, query_field, key) -> None:
    logger.debug(f"Key: {key}")
    delay, itr = 1, 1        
    while(itr <= MAX_LOOP_ITER):
        try:
            web_element = driver.find_element(by_field, query_field)
            driver.execute_script("arguments[0].style.display = 'block';", web_element)
            web_element.clear()
            web_element.send_keys(key)
            break
        except Exception as exp:
            logger.debug(f"Caught this exception {type(exp).__name__}")
            logger.debug(f"Waiting for {delay} seconds and loop iteration {itr}")
            driver.implicitly_wait(delay)
            delay += 1
            itr += 1
    else:
        raise Exception("Max Loop Iterations reached")

@log_entry
def search_for_sr(driver, sr_string) -> None:
    driver.get(urls.SR_URL)

    siebel_form_send_keys(driver = driver, wait_time = 20, 
                          by_field = By.NAME, query_field = names.SR_NUMBER_BOX, 
                          key = sr_string)

    sr_go_button = wdw(driver,10).until(
        EC.presence_of_element_located((By.ID, ids.SERVICE_REQUESTS_GO_BUTTON)) 
    )

    sr_go_button.click()

@log_entry
def close_sr(driver) -> None:
    sr_close_button = wdw(driver, 10).until(
        EC.presence_of_element_located((By.ID, ids.SR_CLOSE_BUTTON))
    )

    sr_close_button.click()

@log_entry
def save_sr(driver) -> None:
    save_button = wdw(driver, 10).until(
        EC.presence_of_element_located((By.ID, ids.SAVE_BUTTON))
    )
    save_button.click()

@log_entry
def open_siebel_navbar_item(driver, item_name) -> None:
    sr_nav_bar = wdw(driver, 10).until(
        EC.presence_of_element_located((By.ID, ids.SR_OPTIONS_NAVIGATION_BAR))
    )

    try:
        sr_nb_item = sr_nav_bar.find_element(By.XPATH, xpaths.SR_NAV_BAR_ITEMS.format(item_name = item_name))
        sr_nb_item.click()
        return
    except Exception:
        logger.debug("Given element not present in the nav bar")
        logger.debug("Opening the drop down")
   
    delay, itr = 1, 1        
    while(itr <= MAX_LOOP_ITER):
        try:
            sr_nb_dropdown_item = sr_nav_bar.find_element(By.XPATH, xpaths.SR_NAV_BAR_DROPDOWN_OPTION.format(item_name = item_name))
            sr_nb_dropdown_item.click()
            break
        except Exception as exp:
            logger.debug(f"Caught this exception {type(exp).__name__}")
            logger.warning("Given Item is not present in the drop down also. Please provide a valid option")
            logger.debug(f"Waiting for {delay} seconds")
            driver.implicitly_wait(delay)
            delay += 1
            itr += 1
    else:
        raise Exception("Max Loop Iterations reached")

@log_entry
def validate_and_update_abstract(driver, abstract: str) -> None:
    sr_abstract_box = wdw(driver, 10).until(
        EC.presence_of_element_located((By.NAME, names.SR_ABSTRACT_BOX))
    )

    set_abstract = sr_abstract_box.get_attribute('value').strip()

    # check if the abstract is empty or len less that 1
    if set_abstract == '' or len(set_abstract) < 1:
        # Assign the dummy SR Note
        logger.info("SR doesn't have an abstract")
        sr_abstract_box.send_keys(abstract)


@log_entry
def add_sr_note(driver, sr_note) -> None: 
    delay, itr = 1, 1        
    while(itr <= MAX_LOOP_ITER):
        try:
            sr_notes_add_button = driver.find_element(By.ID, ids.SR_NOTES_ADD_BUTTON)
            sr_notes_add_button.click()
            break
        except Exception as exp:
            logger.debug(f"Caught this exception {type(exp).__name__}")
            logger.debug(f"Waiting for {delay} seconds")
            driver.implicitly_wait(delay)
            delay += 1
            itr += 1
    else:
        raise Exception("Max Loop Iterations reached")


    delay, itr = 1, 1  
    while(itr <= MAX_LOOP_ITER):
        try: 
            sr_note_div = wdw(driver, 10).until(
                EC.presence_of_element_located((By.ID, ids.SR_NOTE_DIV))
            )  
            desc_element = sr_note_div.find_element(By.XPATH, xpaths.SR_NOTE_DESCRIPTION)
            desc_element.click()
            web_element = sr_note_div.find_element(By.XPATH, xpaths.SR_NOTE_TEXTAREA)
            web_element.click()
            web_element.clear()
            web_element.send_keys(sr_note)
            logger.debug("Note Addeed")
            break
        except Exception as exp:
            logger.debug(f"Caught this exception {type(exp).__name__}")
            logger.debug(f"Waiting for {delay} seconds")
            driver.implicitly_wait(delay)
            delay += 1
            itr += 1
    else:
        raise Exception("Max Loop Iterations reached")


@log_entry
def click_prev_arrow(driver) -> None:
    prev_arrow = wdw(driver,10).until(
        EC.presence_of_element_located((By.ID, ids.PREVIOUS_SR_ARROW)) 
    )
    prev_arrow.click()

@log_entry
def click_next_arrow(driver) -> None:
    next_arrow = wdw(driver,10).until(
        EC.presence_of_element_located((By.ID, ids.NEXT_SR_ARROW)) 
    )
    next_arrow.click()

@log_entry
def get_sr_status(driver) -> str:
    web_element = driver.find_element(By.NAME, names.SR_STATUS_BOX)
    return web_element.get_attribute('value').strip()

@log_entry
def get_sr_index(driver) -> int:
    web_element = driver.find_element(By.ID, ids.SR_COUNT)
    return int(web_element.text.split(" of ")[0])
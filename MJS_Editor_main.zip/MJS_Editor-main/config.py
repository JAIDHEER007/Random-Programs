import os
SCRIPT_ROOT = os.path.dirname(os.path.abspath(__file__))
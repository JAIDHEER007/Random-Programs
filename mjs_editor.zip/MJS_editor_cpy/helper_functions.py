import os
import shutil
from config import SCRIPT_ROOT

mermaid_directory = os.path.join(SCRIPT_ROOT, 'Mermaid_Files')


def create_mermaid_folder(mermaid_unique_id):
    mermaid_folder_path = os.path.join(mermaid_directory, mermaid_unique_id)

    os.makedirs(mermaid_folder_path)

    with open(os.path.join(mermaid_folder_path, 'codefile.txt'), 'w') as file_handle: pass
    with open(os.path.join(mermaid_folder_path, 'mermaid_code.txt'), 'w') as file_handle: pass

    return mermaid_folder_path

def delete_mermaid_folder(mermaid_unique_id):
    mermaid_folder_path = os.path.join(mermaid_directory, mermaid_unique_id)

    if os.path.exists(mermaid_folder_path):
        shutil.rmtree(mermaid_folder_path)



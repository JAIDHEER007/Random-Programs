from flask import Flask, request, render_template, redirect, url_for, jsonify
from flask_migrate import Migrate, migrate
from models import db, Mermaids

import os
import helper_functions

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///datastore.db"

db.init_app(app)

migrate = Migrate(app, db)

from dotenv import load_dotenv
load_dotenv()

global SCRIPT_ROOT
SCRIPT_ROOT = os.path.dirname(os.path.abspath(__file__))

mermaid_directory = os.path.join(SCRIPT_ROOT, 'Mermaid_Files')
if not os.path.exists(mermaid_directory):
    os.makedirs(mermaid_directory)

@app.route('/', methods = ['GET', 'POST'])
def home():
    if request.method == 'GET':
        mermaids = Mermaids.query.all()
        return render_template('home.html', mermaids = mermaids)
    
    mermaid_name = request.form.get('mermaid_name')
    mermaid_description = request.form.get('mermaid_description')

    mermaid = Mermaids(name = mermaid_name, description = mermaid_description)

    db.session.add(mermaid)
    db.session.commit()

    mermaid.folder_path = helper_functions.create_mermaid_folder(mermaid.unique_id)
    db.session.commit()

    return redirect(url_for('show_mermaid', mermaid_id = mermaid.unique_id))

@app.route('/mermaid/<mermaid_id>')
def show_mermaid(mermaid_id):
    mermaid = Mermaids.query.get(mermaid_id)
    return render_template('show_mermaid.html', mermaid = mermaid)

@app.route('/delete_mermaid', methods = ['DELETE'])
def delete_mermaid():
   unique_id = request.form.get('unique_id')
   mermaid = Mermaids.query.get(unique_id)

   helper_functions.delete_mermaid_folder(mermaid_unique_id = unique_id)

   db.session.delete(mermaid)
   db.session.commit()
   return jsonify(delete_done = True, redirect_location = url_for('home'))  

if __name__ == '__main__':
    app.run(host = "0.0.0.0", port = "5537", debug = True)
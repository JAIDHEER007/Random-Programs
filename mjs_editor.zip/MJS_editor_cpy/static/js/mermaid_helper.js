$(function() {
    $('a#delete_mermaid').bind('click', function() {
        $.ajax({
            url: $SCRIPT_ROOT + '/delete_mermaid',
            type: 'DELETE',
            data: {
                'unique_id': $('td#unique_id').html()
            }, 
            success: function(result){
                if(result.delete_done){
                    window.location.href = result.redirect_location; 
                    alert('Deleted Mermaid');
                }else{
                    alert("Error: Unable to Delete");
                }
            }, 
            error: function(){
                alert("Error: Unable to Delete");
            }
        })
        return false;
    });
});